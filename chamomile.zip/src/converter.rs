use rayon::prelude::*;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub struct Converter;

impl Converter {
    /// Параллельная конвертация: читает исходники и сохраняет их как .txt
    pub fn batch_convert_and_export(
        source_paths: &[PathBuf],
        dest_folder: &Path,
        progress: Arc<AtomicUsize>,
        errors: Arc<AtomicUsize>,
    ) {
        source_paths.par_iter().for_each(|src_path| {
            if let Some(file_name) = src_path.file_name() {
                let mut target_name = PathBuf::from(file_name);
                target_name.set_extension("txt");

                let dest_path = dest_folder.join(target_name);

                match fs::read_to_string(src_path) {
                    Ok(content) => {
                        if fs::write(&dest_path, content).is_ok() {
                            progress.fetch_add(1, Ordering::Relaxed);
                        } else {
                            errors.fetch_add(1, Ordering::Relaxed);
                        }
                    }
                    Err(_) => {
                        errors.fetch_add(1, Ordering::Relaxed);
                    }
                }
            }
        });
    }
}