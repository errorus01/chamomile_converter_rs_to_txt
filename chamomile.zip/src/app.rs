use crate::converter::Converter;
use eframe::egui;
use rfd::FileDialog;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use std::thread;

pub struct ChamomileApp {
    files: Vec<PathBuf>,
    is_converting: Arc<AtomicBool>,
    processed_count: Arc<AtomicUsize>,
    error_count: Arc<AtomicUsize>,
    status_msg: String,
    ready_to_export: bool,
}

impl Default for ChamomileApp {
    fn default() -> Self {
        Self {
            files: Vec::new(),
            is_converting: Arc::new(AtomicBool::new(false)),
            processed_count: Arc::new(AtomicUsize::new(0)),
            error_count: Arc::new(AtomicUsize::new(0)),
            status_msg: "Готов к работе. Закидывай файлы.".to_owned(),
            ready_to_export: false,
        }
    }
}

impl ChamomileApp {
    fn import_files(&mut self) {
        if let Some(paths) = FileDialog::new()
            .add_filter("Rust Source", &["rs"])
            .pick_files()
        {
            self.files = paths;
            self.ready_to_export = false;
            self.status_msg = format!("Загружено файлов: {}", self.files.len());
        }
    }

    fn run_conversion(&mut self) {
        if self.files.is_empty() {
            self.status_msg = "Нечего конвертировать! Сначала нажми 'Импорт'.".to_owned();
            return;
        }
        self.ready_to_export = true;
        self.status_msg = format!("Готово к экспорту {} файлов.", self.files.len());
    }

    fn export_files(&mut self) {
        if !self.ready_to_export || self.files.is_empty() {
            self.status_msg = "Сначала нажми 'Конвертировать'!".to_owned();
            return;
        }

        if let Some(dest_dir) = FileDialog::new().pick_folder() {
            let files = self.files.clone();
            let is_converting = Arc::clone(&self.is_converting);
            let progress = Arc::clone(&self.processed_count);
            let errors = Arc::clone(&self.error_count);

            progress.store(0, Ordering::Relaxed);
            errors.store(0, Ordering::Relaxed);
            is_converting.store(true, Ordering::SeqCst);

            self.status_msg = "Экспорт в процессе... 🚀".to_owned();

            // Фоновый поток для Rayon, чтоб UI не фризил
            thread::spawn(move || {
                Converter::batch_convert_and_export(&files, &dest_dir, progress, errors);
                is_converting.store(false, Ordering::SeqCst);
            });
        }
    }
}

impl eframe::App for ChamomileApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();

        // Поддержка Drag & Drop файлов
        if !ctx.input(|i| i.raw.dropped_files.is_empty()) {
            let dropped = ctx.input(|i| i.raw.dropped_files.clone());
            for file in dropped {
                if let Some(path) = file.path {
                    if path.extension().map_or(false, |ext| ext == "rs") {
                        self.files.push(path);
                    }
                }
            }
            self.ready_to_export = false;
            self.status_msg = format!("Всего файлов в очереди: {}", self.files.len());
        }

        let is_busy = self.is_converting.load(Ordering::Relaxed);

        if is_busy {
            ctx.request_repaint(); // Плавный прогресс-бар
        }

        egui::CentralPanel::default().show(ui, |ui| {
            ui.spacing_mut().item_spacing = egui::vec2(8.0, 8.0);

            // Заголовок
            ui.horizontal(|ui| {
                ui.heading("chamomile 🌼");
                ui.label(format!("(Файлов: {})", self.files.len()));
            });
            ui.separator();

            // Кнопки управления
            ui.horizontal(|ui| {
                if ui.add_enabled(!is_busy, egui::Button::new("📥 Импорт")).clicked() {
                    self.import_files();
                }

                if ui.add_enabled(!is_busy && !self.files.is_empty(), egui::Button::new("⚡ Конвертировать")).clicked() {
                    self.run_conversion();
                }

                if ui.add_enabled(!is_busy && self.ready_to_export, egui::Button::new("💾 Экспорт в...")).clicked() {
                    self.export_files();
                }

                if !is_busy && !self.files.is_empty() {
                    if ui.button("🗑 Очистить").clicked() {
                        self.files.clear();
                        self.ready_to_export = false;
                        self.status_msg = "Список очищен.".to_owned();
                    }
                }
            });

            ui.separator();

            // Прогресс
            if is_busy {
                let current = self.processed_count.load(Ordering::Relaxed);
                let errs = self.error_count.load(Ordering::Relaxed);
                let total = self.files.len();
                let ratio = if total > 0 { current as f32 / total as f32 } else { 0.0 };

                ui.add(egui::ProgressBar::new(ratio).show_percentage().animate(true));
                ui.label(format!("Обработано: {}/{} (Ошибок: {})", current, total, errs));
            } else {
                ui.label(format!("Статус: {}", self.status_msg));
            }

            ui.separator();

            // Список с виртуализацией строк
            ui.label("Очередь файлов:");
            egui::ScrollArea::vertical()
                .auto_shrink([false; 2])
                .show_rows(ui, 18.0, self.files.len(), |ui, row_range| {
                    for idx in row_range {
                        if let Some(path) = self.files.get(idx) {
                            ui.label(format!("{}. {}", idx + 1, path.display()));
                        }
                    }
                });
        });
    }
}