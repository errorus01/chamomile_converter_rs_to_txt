#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod app;
mod converter;

use app::ChamomileApp;
use eframe::egui;

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([580.0, 420.0])
            .with_min_inner_size([460.0, 300.0])
            .with_title("chamomile 🌼 rs -> txt converter"),
        ..Default::default()
    };

    eframe::run_native(
        "chamomile",
        options,
        Box::new(|_cc| Ok(Box::new(ChamomileApp::default()))),
    )
}