fn main() {
    #[cfg(windows)]
    {
        let mut res = winres::WindowsResource::new();
        res.set_icon("chamomile.ico"); // путь к твоему .ico в корне
        if let Err(e) = res.compile() {
            eprintln!("Не удалось вшить иконку: {}", e);
        }
    }
}